// Лабораторная работа №5. Применение прерываний в Ардуино
const int buttonPin = 2;
const int ledButton = 13;
const int ledBlink = 8;

volatile bool ledState = false;
volatile unsigned long lastPress = 0;

void buttonISR()
{
  if (millis() - lastPress > 50)
  {
    ledState = !ledState;
    digitalWrite(ledButton, ledState);
    lastPress = millis();
  }
}
void setup() {
  pinMode(ledButton, OUTPUT);
  pinMode(ledBlink, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);
  // Подключение прерывания
  attachInterrupt(digitalPinToInterrupt(buttonPin), buttonISR, FALLING);
}
void loop() {
  digitalWrite(ledBlink, HIGH);
  delay(1000);
  digitalWrite(ledBlink, LOW);
  delay(1000);
}