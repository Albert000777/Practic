//Лабораторная работа №2. Подключение светодиода к Arduino, управлениеосуществляем ШИМ сигналом, включаем через кнопку
// Изменение яркости
const int ledPin = 11;
const int buttonPin = 10;
// Четыре уровня яркости: выключен, слабо, средне, на полную
int levels[] = {0, 8, 100, 255};
int index = 0;
bool lastButton = HIGH;
void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);
}

void loop() {
  if (digitalRead(buttonPin) == LOW)
  {
    index = index + 1;
    if (index > 3)
    {
      index = 0;
    }
    analogWrite(ledPin, levels[index]);
    delay(50);
    while (digitalRead(buttonPin) == LOW)
    {
    }
    delay(50);
  }
}