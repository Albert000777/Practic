// Лабораторная работа №4. Подключение к Arduino сдвигового регистра 74НС595 c помощью интерфейса SPI
//Мигание лампочек сверху вниз
#include <SPI.h>
const int latchPin = 53;
void setup() {
  SPI.begin();
  pinMode(latchPin, OUTPUT);
  Serial.begin(9600);

  digitalWrite(latchPin, LOW);
  SPI.transfer(0);
  digitalWrite(latchPin, HIGH);
}

void loop() {
  for (int i = 0; i < 8; i++) 
  {
    int leds = 1 << i;
    digitalWrite(latchPin, LOW);
    SPI.transfer(leds);
    digitalWrite(latchPin, HIGH);

    Serial.println(leds, BIN);
    delay(250);
  }
  Serial.println("--------");
}