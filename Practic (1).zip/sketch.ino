// КНОПКА ВКЛЮЧАЕТ СВЕТОФОР
void setup() {
  // put your setup code here, to run once:
  pinMode(5, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(2, INPUT_PULLUP);
  
}
boolean buttonWasUp=true;
boolean ledEnabled=false;
void wait1500() 
  {
    for (int i = 0; i < 15; i++) 
    {
      delay(100);
      if (digitalRead(2) == LOW) 
      { 
        ledEnabled = false;        
        return;                    
      }
    }
  }
void loop() {
  // put your main code here, to run repeatedly:
  boolean buttonNowUp = digitalRead(2);
  if (buttonWasUp && !buttonNowUp)
    {
      delay(10);
      buttonNowUp = digitalRead(2);
      if (!buttonNowUp)
      {
        ledEnabled=!ledEnabled;
      }
    }
  buttonWasUp=buttonNowUp;
  //светофор
  if (ledEnabled)
  {
    // красный цвет
    digitalWrite(3, HIGH);// красный включили
    wait1500();
    digitalWrite(3, LOW);// красный выключили
    if (!ledEnabled) return;

    digitalWrite(4, HIGH);//желтый включили
    wait1500();
    digitalWrite(4, LOW);//жельый выключили
    if (!ledEnabled) return;

    digitalWrite(5, HIGH);//зеленый включили
    wait1500();
    digitalWrite(5, LOW);//зеленый выключили
    if (!ledEnabled) return;
  }
  else
  {
    digitalWrite(3, LOW);
    digitalWrite(4, LOW);
    digitalWrite(5, LOW);
  }
}
