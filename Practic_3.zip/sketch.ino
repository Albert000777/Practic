//Лабораторная работа №3. Подключение двигателя постоянного тока к Arduino, управление осуществлением ШИМ сигналом
#include <Stepper.h>

const int stepsPerRev = 200;

Stepper motor(stepsPerRev, 6, 7, 8, 9);
int currentPos = 0;

void setup() {
  motor.setSpeed(60);
}
void loop() {
  int pot = analogRead(A0);
  int target = map(pot, 0, 1023, 0, 200);
  motor.step(target - currentPos);
  currentPos = target;
}
