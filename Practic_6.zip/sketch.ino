// Лабораторная работа №6. Подключение дисплея к плате контроллера Ардуино
#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 7, 6, 5, 4);
const int LM335 = A0;

void setup() {
  lcd.begin(16, 2);
}
void loop() {
  double val = analogRead(LM335);
  double voltage = val * 5.0 / 1024;
  double tempK = voltage * 100;
  double tempC = tempK - 273.15;

  lcd.setCursor(2, 0);
  lcd.print("Tk=");
  lcd.print(tempK, 1);
  lcd.print(" K   ");

  lcd.setCursor(2, 1);
  lcd.print("Tc=");
  lcd.print(tempC, 1);
  lcd.print((char)223);
  lcd.print("C   ");
  delay(1000);
}